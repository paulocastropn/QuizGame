/* Application Purpose: Project Game - Who Wants to Be a Millionaire * 
 * Author: Demilson Moreira Bose Junior, Beatriz Goulart Silva, Pedro Didoné de Vasconcelos, Roselane Gonçalves dos Santos, Paulo de Castro Pinheiro Neto * 
 * Date: 11/07/2023 * 
 * Time: 4:00 pm */

//That first is the major class Quiz Game Test Harness.
public class QuizGameTestHarness {
    // Main Method program entry point.
    public static void main(String[] args) {
        QuizGame quizGame = new QuizGame();
        quizGame.startGame();
    }
}
