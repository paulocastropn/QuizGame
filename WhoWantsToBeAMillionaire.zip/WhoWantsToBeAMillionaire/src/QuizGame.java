/* Application Purpose: Project Game - Who Wants to Be a Millionaire * 
 * Author: Demilson Moreira Bose Junior, Beatriz Goulart Silva, Pedro Didoné de Vasconcelos, Roselane Gonçalves dos Santos, Paulo de Castro Pinheiro Neto * 
 * Date: 11/07/2023 * 
 * Time: 4:00 pm 
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;


// This class  implements the quiz game;
public class QuizGame {
    public void startGame() { //This method is the main entry point for the quiz game. It starts by initializing variables for the number of questions, current question, and an instance of the "QuizGameQuestions" class, which presumably contains the quiz questions
        try {
            //// Initialize variables for the number of questions and the current question.Exception handiling
            int numQuestions = 10; // Number of Questions
            int currentQuestion = 1; // Starting Question

            // Create an instance of the "QuizGameQuestions" class to manage the quiz questions.
            QuizGameQuestions quizGameQuestions = new QuizGameQuestions();

            // Scanner to get user answer
            Scanner scanner = new Scanner(System.in);

            // Print first part of start message. Overloading - Methods of the same name declared in the same class. Must have different sets of parameters
            printStartGameMessage();

            System.out.println("\nPlease, enter your name: ");
            String playerName = scanner.nextLine();
            Player player = new Player(playerName);

            // Print second part of start message. Overloading - Methods of the same name declared in the same class. Must have different sets of parameters
            printStartGameMessage();
            printStartGameMessage(player);

            // Asks the player if he is ready to play and starts the game if the answer is
            // "y" (yes).
            // Otherwise, it displays a message stating that the game has been cancelled.
            System.out.println("\nAre you ready? Answer ONLY Y/N");
            String ready = scanner.nextLine().toLowerCase();

            if (ready.equals("y")) {
                System.out.println("\nStarting the game...");

                // Randomize questions
                Random random = new Random();

                List<String[]> askedQuestions = new ArrayList<>(); // Track asked questions

                // Starts a loop that runs as long as the current question is less than or equal
                // to the total number of questions.
                while (currentQuestion <= numQuestions) {

                    // Selects the appropriate question and answer matrix based on the difficulty of
                    // the current question.
                    if (currentQuestion <= 4) {
                        quizGameQuestions.setDifficulty("Easy");
                    } else if (currentQuestion <= 7) {
                        quizGameQuestions.setDifficulty("Medium");
                    } else {
                        quizGameQuestions.setDifficulty("Hard");
                    }

                    int questionIndex;
                    String[] question;

                    // Randomly selects a question that has not yet been asked, displays the
                    // question and answer choices for the player.
                    do {
                        questionIndex = random.nextInt(quizGameQuestions.getQuizQuestions().length);
                        question = quizGameQuestions.getQuizQuestions()[questionIndex];
                    } while (askedQuestions.contains(question));

                    askedQuestions.add(question); // Add the question to the asked questions list

                    System.out
                            .println("Question " + currentQuestion + " (" + quizGameQuestions.getDifficulty() + "):\n");
                    System.out.println(question[0]); // Display the question

                    for (int i = 1; i <= 4; i++) {
                        System.out.println(question[i]); // Display the answer options
                    }

                    // Requests the player's response and validates that the input is one of the
                    // valid options (A, B, C or D).
                    System.out.print("Your answer: ");
                    String userAnswer = scanner.nextLine().trim().toLowerCase();

                    while (!userAnswer.equals("a") && !userAnswer.equals("b") &&
                            !userAnswer.equals("c") && !userAnswer.equals("d")) {
                        System.out.println("Invalid input! Please enter A, B, C, or D.");
                        System.out.print("Your answer: ");
                        userAnswer = scanner.nextLine().trim().toLowerCase();
                    }
                    // Check if the player's answer is correct and provide feedback.
                    if (userAnswer.equals(question[5].toLowerCase())) {
                        System.out.println("Correct!\n");
                        player.EarnedScore();

                        // Increase the money based on the current question
                        switch (currentQuestion) {
                            case 1:
                                player.setMoney(1000);
                                break;
                            case 2:
                                player.setMoney(5000);
                                break;
                            case 3:
                                player.setMoney(10000);
                                break;
                            case 4:
                                player.setMoney(25000);
                                break;
                            case 5:
                                player.setMoney(50000);
                                break;
                            case 6:
                                player.setMoney(100000);
                                break;
                            case 7:
                                player.setMoney(200000);
                                break;
                            case 8:
                                player.setMoney(300000);
                                break;
                            case 9:
                                player.setMoney(500000);
                                break;
                            case 10:
                                player.setMoney(1000000);
                                break;
                        }

                        System.out.format("You have $%,.2f\n", player.getMoney());

                        /*
                         * Checks if the player has reached a checkpoint (question 5 or question 8) and
                         * gives the option
                         * to continue to the next question or quit with a certain amount of money
                         */
                        if (currentQuestion == 5) {
                            System.out.println(
                                    "\nCongratulations! You reached the checkpoint! Do you want to continue to the next question (Y/N)?");
                            System.out.format("You already have $%,.2f\n", player.getMoney());
                            System.out.println("If you choose not going further, you will earn $10.000,00");
                            String continueAnswer = scanner.nextLine().trim().toLowerCase();
                            if (!continueAnswer.equals("y")) {
                                player.setMoney(10000);
                                System.out.format("Congratulations! You won $%,.2f\n", player.getMoney());
                                break;
                            }
                        }
                        /*
                         * Checks if the player has reached a checkpoint (question 5 or question 8) and
                         * gives the option
                         * to continue to the next question or quit with a certain amount of money
                         */
                        if (currentQuestion == 8) {
                            System.out.println(
                                    "You reached the second checkpoint! Do you want to continue to the next question (Y/N)?");
                            System.out.format("You already have $%,.2f\n", player.getMoney());
                            System.out.println(
                                    "It is only up to you either you are leaving here with a milion dollars today or not!");
                            System.out.println("If you choose not going further, you will earn $100.000,00");
                            String continueAnswer = scanner.nextLine().trim().toLowerCase();
                            if (!continueAnswer.equals("y")) {
                                player.setMoney(100000);
                                System.out.format("Congratulations! You won $%,.2f\n", player.getMoney());
                                break;
                            }
                        }
                    } else {
                        // Handles the player's incorrect response, displays the total amount of money
                        // accumulated, and ends the loop
                        System.out.format("Incorrect answer. Your total amount of money is: $%,.2f\n",
                                player.getMoney());
                        break;
                    }

                    currentQuestion++;
                    System.out.println();
                }
                /*
                 * If all questions are answered, it congratulates the player, displays the
                 * total amount of money won,
                 * and displays an ASCII art of fireworks
                 */
                if (currentQuestion > numQuestions) {
                    System.out.println("Congratulations!");
                    System.out.format("Total amount of money earned: $%,.2f\n", player.getMoney());

                    String asciiArtfireworks = "                                   .''.\n" +
                            "       .''.      .        *''*    :_\\/_:     .\n" +
                            "      :_\\/_:   _\\(/_  .:.*_\\/_*   : /\\ :  .'.:.'.\n" +
                            "  .''.: /\\ :    /)\\   ':'* /\\ *  : '..'.  -=:o:=-\n" +
                            " :_\\/_:'.:::.  | ' *''*    * '\\.'/.'\\(/_'.'.':'.\n" +
                            " : /\\ : :::::  =  *_\\/_*     -= o =- /)\\    '  *\n" +
                            "  '..'  ':::' === * /\\ *     .'/.'.  ' ._____\n" +
                            "      *        |   *..*         :       |.   |' .---\"|\n" +
                            "        *      |     _           .--'|  ||   | _|    |\n" +
                            "     .-----.   |  .-'|       __  |   |  |    ||      |\n" +
                            " ___'       ' /\"\\ |  '-.\"\".    '-'   '-.'    '`      |____\n" +
                            "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n" +
                            "                      ~-~-~-~-~-~-~-~-~-~   /|\n" +
                            "     )          ~-~-~-~-~-~-~-~  /|~       /_|\\\n" +
                            "        _-H-__  -~-~-~-~-~-~     /_|\\    -~======-~\n" +
                            "~-\\XXXXXXXXXX/~     ~-~-~-~     /__|_\\ ~-~-~-~\n" +
                            "-~-~-~-~-~    ~-~~-~-~-~-~    ========  ~-~-~-~";

                    System.out.println(asciiArtfireworks);
                }

            } else {
                System.out.println("OK, you are not ready. Game canceled.");
            }

            scanner.close();
        } catch (Exception e) {
            //// Catch any exceptions that might occur during the game's execution,
            // display an error message, and cancel the game.
            System.out.println(
                    "There was an error during the execution of the game, and it will now terminate. Game canceled.");
            System.out.println(
                    "Error Details: " + e.toString());
        }
    }

    private void printStartGameMessage(Player player) {
        System.out.println("Nice to meet you, " + player.getName() + "\n");

        // Displays an instruction message and displays ASCII art related to the game
        System.out.println("Below you can see the instructions for the game\n");
        String asciiArt = "                                __...--~~~~~-._   _.-~~~~~--...__\n" +
                "                              //               `V'                \\\\ \n" +
                "                             //                 |                  \\\\ \n" +
                "                           //__...--~~~~~~-._   |  _.-~~~~~~--...__\\\\ \n" +
                "                           //__.....----~~~~._\\ | /_.~~~~----.....__\\\\\n" +
                "                           ===================\\\\|//===================\n";

        System.out.println(asciiArt);
        System.out.println(
                "\nThe game contains 10 general questions, every time you get it right you win more money.\r\n" + //
                        "While you are playing you will have the choice of giving up and leaving with $10.000\r\n" + //
                        "after 5 questions or $100.000 when there is only two questions left for one MILLION!\n");
    }

    private void printStartGameMessage() {
        // Introduction displays a welcome message to the user, prompts for the user's
        // name, and stores it in the userName variable
        System.out.println("Welcome! Are You Ready To Became A Millionare?\n");
    }

}
