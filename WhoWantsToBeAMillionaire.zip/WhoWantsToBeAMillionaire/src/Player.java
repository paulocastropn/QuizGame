/* Application Purpose: Project Game - Who Wants to Be a Millionaire * 
 * Author: Demilson Moreira Bose Junior, Beatriz Goulart Silva, Pedro Didoné de Vasconcelos, Roselane Gonçalves dos Santos, Paulo de Castro Pinheiro Neto * 
 * Date: 11/07/2023 * 
 * Time: 4:00 pm 
 * This class provides a basic blueprint for creating player objects in a game. 
 * It encapsulates the player's data (name, score, and money) and ensures controlled access to these attributes through getter and setter methods.
*/
public class Player {
    private String name; // Player Name
    private int score; // Player Score
    private double money; // Player Money

    // Constructor that takes the player's name as a parameter.
    public Player(String name) {
        this.name = name;
        score = 0;
        money = 0;
    }

    // Getter method allow access to the private attributes, providing read access
    public String getName() {
        return name;
    }

    // Setter method enable modification of the private attributes, offering write access
    public void setName(String name) {
        this.name = name;
    }

    // Getter method
    public int getSCore() {
        return score;
    }

    // Setter method
    public void setScore(int score) {
        this.score = score;
    }

    // Getter method
    public double getMoney() {
        return money;
    }

    // Setter method
    public void setMoney(double money) {
        this.money = money;
    }

    public void EarnedScore() {
        this.score++;
    }
    
}